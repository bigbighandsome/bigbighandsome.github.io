import{I as e}from"./index-1cf03590.js";const o=e("course",{state:()=>({usertoken:"",x_id_token:"",token:"",kbjcmsid:""}),actions:{},getters:{}});export{o as C};
